# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'ain^t(-g&+tm4u4jb&g3a^)1u!cy!@4k968ywo57o#v8s35zw@'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True