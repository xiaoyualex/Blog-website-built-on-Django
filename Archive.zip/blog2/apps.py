from django.apps import AppConfig


class Blog2Config(AppConfig):
    name = 'blog2'
